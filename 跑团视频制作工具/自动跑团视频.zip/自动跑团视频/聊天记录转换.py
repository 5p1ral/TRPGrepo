import time
f=open("凉哥手撕古神直播群.txt","r",encoding="utf-8")
x=f.read()
f.close()

for i in range(len(x)):
    if(x[i]==")"and x[i+1]=="\n" and x[i+2]=="\n"):
        x=x[:i+2]+"0"+x[i+2:]
    if(x[i:i+3]=="总和："):
        if(x[i+6]=="\n" and x[i+7]=="\n"):
            x=x[:i+7]+"0"+x[i+7:]

x=x.split("\n\n")
for i in range(len(x)):
    x[i]=x[i].split("\n")


bz=time.strptime("2020-7-24 22:51:58","%Y-%m-%d %H:%M:%S")
bz=time.mktime(bz)
for i in range(len(x)):
    _time=x[i][0].split(" ")[0]+" "+x[i][0].split(" ")[1]
    _time="".join(_time.split("\ufeff"))
    timeArray = time.strptime(_time,"%Y-%m-%d %H:%M:%S")
    timeArray =time.mktime(timeArray)
    if(bz<=timeArray):
        break
x=x[i:]

bz=time.strptime("2020-07-25 1:46:46","%Y-%m-%d %H:%M:%S")
bz=time.mktime(bz)
for i in range(len(x)):
    _time=x[i][0].split(" ")[0]+" "+x[i][0].split(" ")[1]
    _time="".join(_time.split("\ufeff"))
    timeArray = time.strptime(_time,"%Y-%m-%d %H:%M:%S")
    timeArray =time.mktime(timeArray)
    if(bz<=timeArray):
        break
x=x[:i]

for i in range(len(x)):
    asd=[]
    for j in range(1,len(x[i])):
        asd.append(x[i][j])
    x[i]=[x[i][0],"。".join(asd)]
name=["枫羽","女儿","sma","沈辰汐","332","凉哥","水畔狐"]
cg=["枫羽","lorina","布兰莎","艾德兰","埃利亚","凉雨","ST"]
    
y=[]
a=['(',')','（','）']
for i in range(len(x)):
    flag=0
    for j in a:
        if(j in x[i][1]):
            flag=1
            break
    if(flag==1):
        continue
    if("系统消息" in x[i][0]):
        continue
    for j in range(len(name)):
        if(name[j] in x[i][0]):
            x[i][0]=cg[j]
    y.append(x[i])

for i in range(len(y)):
    y[i]="\n".join(y[i])
y="\n\n".join(y)
f=open("凉哥手撕古神直播群0.txt","w",encoding="utf-8")
f.write(y)
f.close()
